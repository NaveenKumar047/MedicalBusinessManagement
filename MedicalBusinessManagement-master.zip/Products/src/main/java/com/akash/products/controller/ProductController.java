package com.akash.products.controller;

import java.nio.file.AccessDeniedException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.akash.products.entity.Products;
import com.akash.products.entity.User;
import com.akash.products.service.ProductsService;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductsService service;

	@Autowired
	RestTemplate template;
	//using the Zuul proxy -> Authenticate using the Authentication server
	final String url = "http://localhost:8761/user";
	String userRole = null;

	public User getUserDetails(HttpServletRequest request) {
		String header = request.getHeader("Authorization");
		HttpHeaders http = new HttpHeaders();
		System.out.println(header);
		String token = header.substring(7);
		System.out.println("Token = " + token);
		http.add("Authorization", "Bearer " + token);
		HttpEntity<String> entity = new HttpEntity<String>(http);
		ResponseEntity<User> output = template.exchange(url + "/findDetails/" + token, HttpMethod.GET, entity,
				User.class);
		System.out.println("Attribute: " + header);
		User user = output.getBody();
		userRole = user.getRole();
		return user;
	}

	@PostMapping("/create")
	public Products createProduct(@RequestBody Products product, HttpServletRequest request)
			throws AccessDeniedException {
		String role = getUserDetails(request).getRole();
		if (role == null || role.contains("customer"))
			throw new AccessDeniedException("You do not have the required access");
		return service.save(product);
	}

	@GetMapping("/find")
	public List<Products> findAllProducts(HttpServletRequest request) throws AccessDeniedException {
		String role = getUserDetails(request).getRole();
		if (role == null)
			throw new AccessDeniedException("You do not have the required access");

		return service.findAll();
	}

	@GetMapping("/find/{id}")
	public Optional<Products> findById(@PathVariable("id") Integer id, HttpServletRequest request)
			throws AccessDeniedException {
		String role = getUserDetails(request).getRole();
		if (role == null)
			throw new AccessDeniedException("You do not have the required access" + role);
		return service.findById(id);
	}

	@PutMapping("/update/{id}")
	public Object updateProduct(@PathVariable("id") Integer id, @RequestBody Products freshProduct,
			HttpServletRequest request) throws AccessDeniedException {

		String role = getUserDetails(request).getRole();
		if (role == null || role.contains("customer"))
			throw new AccessDeniedException("You do not have the required access");

		if (service.findById(id) == null) {
			return ResponseEntity.badRequest();
		}

		freshProduct.setId(id);
		return service.save(freshProduct);
	}

}
