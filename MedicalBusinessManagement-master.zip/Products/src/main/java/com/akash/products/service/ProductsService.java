package com.akash.products.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akash.products.entity.Products;
import com.akash.products.repository.ProductsRepository;

@Service
public class ProductsService {

	@Autowired
	ProductsRepository repo;

	public Products save(Products product) {

		return repo.save(product);

	}

	public List<Products> findAll() {
		return repo.findAll();
	}

	public Optional<Products> findById(Integer id) {

		return repo.findById(id);
	}

}
