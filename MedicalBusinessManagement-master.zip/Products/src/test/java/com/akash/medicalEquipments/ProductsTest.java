package com.akash.medicalEquipments;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

import com.akash.products.entity.Products;
import com.akash.products.repository.ProductsRepository;
import com.akash.products.service.ProductsService;

public class ProductsTest {

	@Test
	public void ProductSaveTest() {
		
		
		ProductsService repository = mock(ProductsService.class);
		Products product = new Products();
		product.setId(101);
		product.setName("Test");
		product.setPrice(5000.0);

		Products actual = new Products();
		actual.setId(101);
		actual.setName("Test");
		actual.setPrice(5000.0);

		when(repository.save(product)).thenReturn(actual);
		Products test = repository.save(product);
		assertEquals(test.getPrice(), product.getPrice());

	}

}
