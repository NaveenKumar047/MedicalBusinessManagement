package com.akash.orderDetails;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.barath.orderDetails.models.Orders;
import com.barath.orderDetails.repository.OrderRepository;

class OrderTests {

	@Test
	void test() {

		OrderRepository orderRepository = mock(OrderRepository.class);

		Orders orders = new Orders();
		Orders testOrder = new Orders();
		testOrder.setOrderID(101);
		testOrder.setOrderStatus("pending");

		List<Integer> productIdList = new ArrayList<>();
		productIdList.add(1);
		productIdList.add(2);
		productIdList.add(3);
		testOrder.setProducts(productIdList);
		testOrder.setUserId("testuser@test.com");

		orders.setOrderID(101);
		orders.setOrderStatus("pending");
		orders.setProducts(productIdList);
		orders.setUserId("testuser@test.com");

		when(orderRepository.save(testOrder)).thenReturn(orders);

		Orders save = orderRepository.save(testOrder);
		assertEquals(save, testOrder);
	}

}
