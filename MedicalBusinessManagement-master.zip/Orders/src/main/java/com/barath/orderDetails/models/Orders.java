package com.barath.orderDetails.models;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
public class Orders {
	@Id
	@GeneratedValue
	private Integer orderID;
	private String userId;
	private String orderStatus = "Pending";
	@ElementCollection(targetClass = Integer.class)
	private List<Integer> products;
}
