package com.barath.orderDetails.models;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Component
@Entity
public class OrderDetails {

	@Id
	private Integer orderId;
	private String userId;
	private String orderStatus = "unpaid";
	private Double amount;
	@ElementCollection(targetClass = String.class)
	private List<String> productsOrdered;

}
