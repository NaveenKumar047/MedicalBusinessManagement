package com.barath.orderDetails.models;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@ToString
public class User {
	private String email;
	private String username;
	private String password;
	private String role;
}
