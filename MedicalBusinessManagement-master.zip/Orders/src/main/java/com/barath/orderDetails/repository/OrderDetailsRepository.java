package com.barath.orderDetails.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.barath.orderDetails.models.OrderDetails;

@Repository
public interface OrderDetailsRepository extends JpaRepository<OrderDetails, Integer> {

	@Query("FROM OrderDetails where userId= :userId")
	List<OrderDetails> findAllByUserId(String userId);

	@Query("FROM OrderDetails where orderStatus='unpaid' and user_id=:userId")
	List<OrderDetails> findAllUnpaid(String userId);

	@Query("FROM OrderDetails where user_id=:userId and order_id=:orderId")
	Optional<OrderDetails> findOrderByOrderIdAndUserId(int orderId, String userId);


}
