package com.barath.orderDetails.controller;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.barath.orderDetails.models.OrderDetails;
import com.barath.orderDetails.models.Orders;
import com.barath.orderDetails.models.Products;
import com.barath.orderDetails.models.User;
import com.barath.orderDetails.repository.OrderDetailsRepository;
import com.barath.orderDetails.repository.OrderRepository;
import com.sun.jersey.api.NotFoundException;

@RequestMapping("/order")
@RestController
public class OrderController {

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	RestTemplate template;

	@Autowired
	OrderDetails orderDetails;

	@Autowired
	OrderDetailsRepository orderDetailsRepository;

	final String url = "http://localhost:8764/user";
	String userRole = null;

	// Hit the authentication server and validate the request for each request !
	public User getUserDetails(HttpServletRequest request) {
		String header = request.getHeader("Authorization");
		HttpHeaders http = new HttpHeaders();
		System.out.println(header);
		String token = header.substring(7);
		http.add("Authorization", "Bearer " + token);
		HttpEntity<String> entity = new HttpEntity<String>(http);
		ResponseEntity<User> output = template.exchange(url + "/findDetails/" + token, HttpMethod.GET, entity,
				User.class);
		System.out.println("Attribute: " + header);
		User user = output.getBody();
		System.err.println(user);
		userRole = user.getRole();
		return user;
	}

	@PostMapping("/hi")
	public Orders createOrder(@RequestBody Orders order, HttpServletRequest request) throws AccessDeniedException {
		String userId = getUserDetails(request).getEmail();
		String role = getUserDetails(request).getRole();
		if (role == null || role.equals("admin"))
			throw new AccessDeniedException("You do not have the required access");

		order.setUserId(userId);
		List<Integer> productIds = order.getProducts();
		
		String header = request.getHeader("Authorization");
		HttpHeaders http = new HttpHeaders();
		System.out.println(header);
		String token = header.substring(7);
		http.add("Authorization", "Bearer " + token);
		HttpEntity<String> entity = new HttpEntity<String>(http);
		for (Integer id : productIds) {

			Products product = template
					.exchange("http://localhost:8762/product/item/" + id, HttpMethod.GET, entity, Products.class)
					.getBody();
			System.out.println(product);
			if (product == null) {
				throw new NullPointerException();
			}

		}
		System.err.println(role+":"+userId+":"+productIds);
		Orders obj=new Orders();
		obj.setUserId(userId);
		obj.setOrderStatus("BOOKED");
		obj.setProducts(productIds);
		orderRepository.save(order);

		
		return order;
	}
	// only allow customer
	@PostMapping("/create")
	public Orders createOrders(@RequestBody Orders order, HttpServletRequest request) throws AccessDeniedException {

		String userId = getUserDetails(request).getEmail();
		// orderId is auto generated
		// userId is set from security context ( got from context )
		// only customers should be able to place orders ( done )
		String role = getUserDetails(request).getRole();
		System.err.println(role+":"+userId);
		if (role == null || role.equals("admin"))
			throw new AccessDeniedException("You do not have the required access");

		order.setUserId(userId);
		String header = request.getHeader("Authorization");
		HttpHeaders http = new HttpHeaders();
		System.out.println(header);
		String token = header.substring(7);
		http.add("Authorization", "Bearer " + token);
		HttpEntity<String> entity = new HttpEntity<String>(http);

		List<Integer> productIds = order.getProducts();
		for (Integer id : productIds) {

			Products product = template
					.exchange("http://localhost:8762/product/item/" + id, HttpMethod.GET, entity, Products.class)
					.getBody();
			if (product == null) {
				throw new NullPointerException();
			}

		}
		orderRepository.save(order);

		// saving order and orderDetails
		int orderId = order.getOrderID();
		orderDetails.setOrderId(orderId);

		// order details userID
		orderDetails.setUserId(userId);

		List<Products> products = new ArrayList<>();
		Optional<Orders> findById = orderRepository.findById(orderId);
		Orders orders = findById.get();

		List<Integer> ids = orders.getProducts();
		for (int id : ids) {
			products.add(template
					.exchange("http://localhost:8762/product/item/" + id, HttpMethod.GET, entity, Products.class)
					.getBody());
		}
		List<String> productNames = new ArrayList<>();
		double sum = 0;
		for (Products product : products) {
			productNames.add(product.getName());
			sum += product.getPrice();
		}
		orderDetails.setProductsOrdered(productNames);
		orderDetails.setAmount(sum);
		orderDetailsRepository.save(orderDetails);
		return order;
	}

	@PutMapping("/admin/updateOrder/{orderId}")
	public Orders changeOrderStatusAdmin(@RequestBody String orderStatus, @PathVariable("orderId") Integer orderId,
			HttpServletRequest request) throws AccessDeniedException {

		String role = getUserDetails(request).getRole();
		if (role == null || !role.contains("admin"))
			throw new AccessDeniedException("You do not have the required access");
		Orders order = orderRepository.findById(orderId).get();
		order.setOrderID(orderId);
		order.setOrderStatus(orderStatus);
		order.setProducts(order.getProducts());
		return orderRepository.save(order);
	}

	@RequestMapping("/find/{id}")
	public Optional<OrderDetails> viewOrderById(@PathVariable("id") int orderId, HttpServletRequest request)
			throws AccessDeniedException {

		String role = getUserDetails(request).getRole();
		if (role == null || role.contains("admin"))
			throw new AccessDeniedException("You do not have the required access");
		String userId = getUserDetails(request).getEmail();
		return orderDetailsRepository.findOrderByOrderIdAndUserId(orderId, userId);
	}

	@DeleteMapping("/deleteOrder/{orderId}")
	public void deleteTemp(@PathVariable("orderId") Integer orderId, HttpServletRequest request)
			throws AccessDeniedException {

		String role = getUserDetails(request).getRole();
		if (role == null || !role.contains("admin"))
			throw new AccessDeniedException("You do not have the required access");
		String userId = getUserDetails(request).getEmail();
		System.out.println(userId);
		System.out.println(orderDetailsRepository.findById(orderId).get().getUserId());

		if (userId.equals(orderDetailsRepository.findById(orderId).get().getUserId()))
			orderDetailsRepository.deleteById(orderId);
		else
			throw new AccessDeniedException("NOT YOUR ORDER TO DELETE");
	}

	@RequestMapping("/find")
	public List<OrderDetails> viewAllOrders(HttpServletRequest request) throws AccessDeniedException {

		String role = getUserDetails(request).getRole();
		if (role == null || role.contains("admin"))
			throw new AccessDeniedException("You do not have the required access");

		String userId = getUserDetails(request).getEmail();
		return orderDetailsRepository.findAllByUserId(userId);

	}

	// secure - Only admin can see all IDs

	@RequestMapping("/admin/find")
	public List<OrderDetails> getAllOrderAdmin(HttpServletRequest request) {
		return orderDetailsRepository.findAll();
	}

	@PutMapping("/update/{orderId}")
	public Orders updateOrder(@PathVariable("orderId") Integer orderId, @RequestBody Orders order,
			HttpServletRequest request) throws Exception {

		Orders oldOrder = orderRepository.findById(orderId).get();
		if (oldOrder == null) {
			throw new NotFoundException("Order ID is invalid");
		}

		if (orderDetailsRepository.findById(orderId).get().getOrderStatus().equalsIgnoreCase("paid")) {
			throw new Exception("Order already fulfilled");
		}

		String userId = getUserDetails(request).getEmail();

		if (!userId.equals(orderRepository.findById(orderId).get().getUserId())) {
			throw new AccessDeniedException("Not your order");
		}

		order.setOrderID(orderId);
		order.setUserId(userId);
		Orders save = orderRepository.save(order);

		orderDetails.setOrderId(orderId);
		// order details userID
		orderDetails.setUserId(userId);

		List<Products> products = new ArrayList<>();
		Orders orders = orderRepository.findById(orderId).get();

		String header = request.getHeader("Authorization");
		HttpHeaders http = new HttpHeaders();
		System.out.println(header);
		String token = header.substring(7);
		http.add("Authorization", "Bearer " + token);
		HttpEntity<String> entity = new HttpEntity<String>(http);

		List<Integer> ids = orders.getProducts();
		for (int id : ids) {
			products.add(template
					.exchange("http://localhost:8762/product/item/" + id, HttpMethod.GET, entity, Products.class)
					.getBody());
		}

		List<String> productNames = products.parallelStream().map(i -> i.getName()).collect(Collectors.toList());
		double sum = products.parallelStream().mapToDouble(i -> i.getPrice()).sum();
		orderDetails.setProductsOrdered(productNames);
		orderDetails.setAmount(sum);
		orderDetailsRepository.save(orderDetails);
		return save;
	}

	@RequestMapping("/totalPayable")
	public String totalPayableAmount(HttpServletRequest request) {
		String userId = getUserDetails(request).getEmail();
		List<OrderDetails> unpaidOrders = orderDetailsRepository.findAllUnpaid(userId);
		Double payable = unpaidOrders.parallelStream().mapToDouble(i -> i.getAmount()).sum();
		return "Total Payable is: " + payable;
	}

	@RequestMapping("/paymentDone")
	public String thankYouForPayment(HttpServletRequest request) {
		String userId = getUserDetails(request).getEmail();
		int count = 0;
		List<OrderDetails> unpaidOrders = orderDetailsRepository.findAllUnpaid(userId);
		for (OrderDetails order : unpaidOrders) {
			++count;
			order.setOrderStatus("Paid");
			orderDetailsRepository.save(order);
		}
		if (count == 0) {
			return "No unpaid order";
		}
		return "Thank you for your payment !!";
	}

}
