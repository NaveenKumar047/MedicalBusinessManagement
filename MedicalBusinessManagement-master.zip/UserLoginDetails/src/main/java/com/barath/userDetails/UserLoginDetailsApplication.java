package com.barath.userDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
public class UserLoginDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserLoginDetailsApplication.class, args);
	}

}
