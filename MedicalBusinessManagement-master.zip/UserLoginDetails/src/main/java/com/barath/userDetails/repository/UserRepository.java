package com.barath.userDetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.barath.userDetails.models.User;


@Repository
public interface UserRepository extends JpaRepository<User, String> {

	@Query("FROM User where email= :userId")
	User findAdminByUsername(String userId);

	@Query(value = "Select role from user where email= :username", nativeQuery = true)
	String getAuthority(String username);

	@Query(value = "SELECT username from user where email= :email ", nativeQuery = true)
	String findUsernameById(String email);

}
