package com.barath.userDetails.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.barath.userDetails.exceptions.CustomException;
import com.barath.userDetails.models.AuthenticationResponse;
import com.barath.userDetails.models.User;
import com.barath.userDetails.repository.UserRepository;
import com.barath.userDetails.service.MyUserDetailsService;
import com.barath.userDetails.util.JwtUtil;



@RestController
@RequestMapping("/user")
public class UserLoginController {

	@Autowired
	UserRepository repo;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	MyUserDetailsService myUserDetails;

	@Autowired
	JwtUtil jwtUtil;

	@PostMapping("/create")
	public User createUser(@RequestBody User user) {
		return repo.save(user);

	}

	@RequestMapping("/greet")
	public String greet(Principal principal) {
		return "Hello, " + principal.getName();
	}

	@PutMapping("/update/{id}")
	public User updateUser(@PathVariable("id") String id, @RequestBody User user) throws CustomException {

		if (repo.findById(id).get() == null) {
			throw new CustomException("ID is not found");
		}
		return repo.save(user);
	}

	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable("id") String id, Principal user) throws CustomException {

		if (id.equals(user.getName())) {
			throw new CustomException("Cannot delete self");
		}
		repo.deleteById(id);
		return "User successfully deleted";

	}

	@PostMapping("/authenticate")
	public ResponseEntity<?> login(@RequestBody User user) throws BadCredentialsException {
		myUserDetails.setRole(repo.getAuthority(user.getEmail()));
		try {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
		} catch (BadCredentialsException e) {
			throw new BadCredentialsException("Incorrect Username or password");
		}
		final UserDetails userDetails = myUserDetails.loadUserByUsername(user.getEmail());
		final String jwt = jwtUtil.generateToken(userDetails);
		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}

	@RequestMapping("/findDetails/{jwtToken}")
	public User getAllDetails(@PathVariable("jwtToken") String jwtToken) {

		User user = new User();
		user.setEmail(jwtUtil.extractUsername(jwtToken));
		user.setUsername(repo.findUsernameById(user.getEmail()));
		user.setPassword("[CONFIDENTIAL]");
		String role = repo.getAuthority(user.getEmail());
		user.setRole(role);
		return user;

	}

	@RequestMapping("/find")
	public List<User> getAllUsers() {
		return repo.findAll();
	}

}
