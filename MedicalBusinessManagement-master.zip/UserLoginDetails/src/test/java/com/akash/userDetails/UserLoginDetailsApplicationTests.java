package com.akash.userDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLoginDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
